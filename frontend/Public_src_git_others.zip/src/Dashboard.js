import React, { useState } from "react";
import AddBook from "./components/AddBook";
import AddMember from "./components/AddMember";
import BorrowBook from "./components/BorrowBook";
import ReturnBook from "./components/ReturnBook";
import ListBooks from "./components/ListBooks";
import ListMembers from "./components/ListMembers";
import MemberBorrowReport from "./components/MemberBorrowReport";
import BookWiseBorrowReport from "./components/BookWiseBorrowReport";
import OverdueReturnReport from "./components/OverdueReturnReport";
import AvailableBooks from "./components/AvailableBooks";
import "./Dashboard.css";
import libraryIcon from "./assets/books.jpeg";

function Dashboard() {
  const [activePage, setActivePage] = useState("home");
  const [showAddMenu, setShowAddMenu] = useState(false);
  const [showReports, setShowReports] = useState(false);

  const renderPage = () => {
    switch (activePage) {
      case "addBook": return <AddBook />;
      case "addMember": return <AddMember />;
      case "borrowBook": return <BorrowBook />;
      case "returnBook": return <ReturnBook />;
      case "listBooks": return <ListBooks />;
      case "listMembers": return <ListMembers />;
      case "availableBooks": return <AvailableBooks />;
      case "memberReport": return <MemberBorrowReport />;
      case "bookReport": return <BookWiseBorrowReport />;
      case "overdueReport": return <OverdueReturnReport />;
      default:
        return <div className="placeholder-text">Please select an option from the menu.</div>;
    }
  };

  return (
    <div className="dashboard-container">

      <div className="dashboard-header">
        <img src={libraryIcon} className="header-icon" alt="Library Icon" />
        <span className="header-title">Neighborhood Library Management System</span>
      </div>

      <div className="dashboard-body">

        {/* LEFT MENU */}
        <div className="left-menu">

          <div className="menu-item dropdown" onClick={() => setShowAddMenu(!showAddMenu)}>
            Add ▼
          </div>
          {showAddMenu && (
            <div className="dropdown-items">
              <div className="submenu-item" onClick={() => setActivePage("addBook")}>Book</div>
              <div className="submenu-item" onClick={() => setActivePage("addMember")}>Member</div>
            </div>
          )}

          <div className="menu-item" onClick={() => setActivePage("borrowBook")}>
            Borrow Book
          </div>

          <div className="menu-item" onClick={() => setActivePage("returnBook")}>
            Return Book
          </div>

          <div className="menu-item dropdown" onClick={() => setShowReports(!showReports)}>
            Reports ▼
          </div>

          {showReports && (
            <div className="dropdown-items">
              <div className="submenu-item" onClick={() => setActivePage("memberReport")}>
                Member Book Borrow Report
              </div>

              <div className="submenu-item" onClick={() => setActivePage("availableBooks")}>
                Available Book List
              </div>

              <div className="submenu-item" onClick={() => setActivePage("overdueReport")}>
                Overdue Return Report
              </div>

              <div className="submenu-item" onClick={() => setActivePage("bookReport")}>
                Book-wise Borrowers Report
              </div>
            </div>
          )}

        </div>

        {/* RIGHT PANEL */}
        <div className="right-panel">{renderPage()}</div>

      </div>
    </div>
  );
}

export default Dashboard;