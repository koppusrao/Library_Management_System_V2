import React from "react";
import Dashboard from "./Dashboard";
import "./App.css";

// Correct path for background image
import libraryBg from "./assets/library-bg.jpg";

function App() {
  return (
    <div 
      className="App-header" 
      style={{ backgroundImage: `url(${libraryBg})` }}
    >
      <Dashboard />
    </div>
  );
}

export default App;